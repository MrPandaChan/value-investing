#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
财报拆解 V1.1.0 — 核验计算脚本（同一输入同一输出，防 LLM 计算幻觉）
用法: python calc_teardown_metrics.py <拆解数据.json>
覆盖核验体系: 分部加总 / FCF 自算 / 股数勾稽 / 毛利率自算 / YoY 增速

输入 JSON 结构：
  顶层: company/period/unit["亿元"|"十亿美元"] | segments_prev/segments 分部数组[{name,value}] |
        total_prev/total 披露总计(核验用) | current/previous 两期对象
  current/previous: revenue 营收 | cogs 营业成本 | ocf 经营现金流 | capex 资本开支 |
        net_profit 净利(归母/Non-IFRS/经调整,口径注明) | eps 每股收益 | shares 总股本(亿股) |
        rd_expense 研发费用 | operating_profit 经营利润
  注意：金额单位统一（美股 $B 时请全文一致）；缺数据字段省略禁填 0"""
import json, sys, argparse

def r2(x): return round(x, 2) if isinstance(x, (int, float)) else None
def sd(a, b):
    if a is None or b is None or b == 0: return None
    return a / b

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("--out", default=None)
    args = ap.parse_args()
    d = json.load(open(args.input, encoding="utf-8"))
    gaps, out = [], {"skill": "financial-report-teardown", "version": "1.1.0",
                     "company": d.get("company"), "period": d.get("period"),
                     "unit": d.get("unit", "亿元"),
                     "calculation_guarantee": "同一输入同一输出；缺数据标【无数据】禁 0 填充"}

    # 1) 分部加总核验（两期）
    for pk in ("segments_prev", "segments"):
        segs = d.get(pk)
        if not segs: continue
        # 优先 total_<pk>（如 total_segments_prev）；基期按 docstring 约定回退 total_prev，本期回退 total
        total_declared = d.get(f"total_{pk}")
        if total_declared is None:
            total_declared = d.get("total_prev") if pk == "segments_prev" else d.get("total")
        s = sum(x.get("value") or 0 for x in segs)
        out[f"{pk}_sum"] = r2(s)
        if total_declared is not None:
            dev = abs(s - total_declared) / total_declared * 100 if total_declared else None
            out[f"{pk}_check"] = {"declared": r2(total_declared), "computed": r2(s),
                                  "deviation_pct": r2(dev), "verdict": "PASS" if dev is not None and dev <= 1 else "FAIL(分部加总≠总计,须查明)"}

    # 2) 盈利与现金流（单期 + 上年同期）
    cur, prev = d.get("current", {}), d.get("previous", {})
    rev, cogs = cur.get("revenue"), cur.get("cogs")
    out["gross_margin_self"] = f"{sd(rev - cogs, rev)*100:.2f}%" if rev and cogs is not None else None
    ocf, capex, np_ = cur.get("ocf"), cur.get("capex"), cur.get("net_profit")
    out["fcf_self"] = r2(ocf - capex) if ocf is not None and capex is not None else "【无数据】禁0近似"
    eps, shares = cur.get("eps"), cur.get("shares")
    if np_ and eps:
        implied = np_ / eps
        out["share_check"] = {"np_over_eps": r2(implied), "declared_shares": shares,
                              "deviation_pct": r2(abs(implied - shares) / shares * 100) if shares else None,
                              "verdict": "PASS(<2%)" if shares and abs(implied - shares) / shares <= 0.02 else "FAIL(>2%须查明)"}
    else:
        gaps.append("净利/EPS 缺失，股数勾稽无法执行")

    # 3) YoY 增速
    for k in ("revenue", "net_profit", "ocf", "rd_expense", "operating_profit"):
        c, p = cur.get(k), prev.get(k)
        out[f"yoy_{k}"] = f"{(c-p)/abs(p)*100:+.2f}%" if c is not None and p not in (None, 0) else None

    out["data_gaps"] = gaps
    s = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out: open(args.out, "w", encoding="utf-8").write(s); print(f"written: {args.out}")
    else: print(s)

if __name__ == "__main__":
    main()
