#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
财报排雷 V1.1.0 — 量化指标计算脚本（同一输入同一输出，防 LLM 计算幻觉）
用法: python calc_risk_metrics.py <财报数据.json> [--out 输出.json]
输出: 计算结果 JSON——LLM 拿本输出做定性判断与评分，禁止心算替代

输入 JSON 结构（顶层: company/code/market["A股"|"港股"|"美股"]/periods[]）：
  periods[] 每期字段（全部可选；金额单位统一【亿元】；均为【累计值】非单季值——
  从数据源取数时注意区分"本期累计"与"单季(_Q)"字段，如 westock 的 TotalProfit 为累计、TotalProfit_Q 为单季）：
  ─ 利润表: revenue 营业收入 | cogs 营业成本 | tax_surcharge 税金及附加(港股无此科目置null) |
    selling_exp 销售费用 | admin_exp 管理费用 | rd_exp 研发费用 | interest_expense 利息费用(正值科目,禁用财务费用整体) |
    other_income 其他收益 | investment_income 投资收益 | fv_change 公允价值变动 |
    asset_impairment 资产减值 | credit_impairment 信用减值 | total_profit 利润总额 |
    np_consolidated 合并净利润 | np_parent 归母净利润 | np_deducted 扣非归母 | income_tax 所得税
  ─ 现金流: ocf 经营现金流净额 | capex 购建长期资产支付现金 | sales_cash 销售商品收到的现金 |
    icf 投资现金流净额 | cff 筹资现金流净额
  ─ 资产负债: cash 货币资金(期末) | cash_prev 货币资金(期初,R011年化用) | interest_income 利息收入 |
    total_assets 总资产 | interest_bearing_debt 有息负债 |
    notes_payable 应付票据 | accounts_payable 应付账款 | advance_receipts 预收款项 | contract_liabilities 合同负债 |
    notes_receivable 应收票据 | accounts_receivable 应收账款 | prepayments 预付款项 | contract_assets 合同资产 |
    dividends_paid 现金分红总额
  ─ 元信息: end_date 报告期 | months 报告期月数(默认12,中报6/季报3,R011年化用) | note 备注(透传到输出)
"""
import json, sys, argparse

def r2(x):
    return round(x, 2) if isinstance(x, (int, float)) else None

def safe_div(a, b):
    if a is None or b is None or b == 0:
        return None
    return a / b

def pct(x):
    return f"{x*100:.2f}%" if isinstance(x, (int, float)) else None

# —— 现金流量肖像八型（CFO, CFI, CFF 符号） ——
PORTRAIT = {
    "+++": ("妖精型", "事反必妖：无大规模投资计划则远离；有则按蛮牛型关注"),
    "++-": ("老母鸡型", "收获期；投资流入非变卖+双流入覆盖筹资流出=健康；近似债券，看低PE+高股息"),
    "+-+": ("蛮牛型", "项目前景第一；经营+筹资能否撑到产出现金；股权筹资须疑被迫低价"),
    "+--": ("奶牛型", "可持续=经营流入>投资流出+非分红筹资流出；否则随时变蛮牛"),
    "---": ("大出血型", "不久于人世型，须堵血/输血；远离"),
    "--+": ("赌徒型", "生意收不到钱靠筹资下注；看品性与赌运，远离"),
    "-+-": ("混吃等死型", "变卖家当=真混吃等死；所投公司分红回流=整容老母鸡（验现金净增加额>0）"),
    "-++": ("骗吃骗喝型", "变卖家当+还能借钱；若投资流入实为分红回流则按妖精型处理"),
}

def core_profit(p):
    parts = [p.get("revenue"), p.get("cogs"), p.get("tax_surcharge"),
             p.get("selling_exp"), p.get("admin_exp"), p.get("rd_exp")]
    if any(v is None for v in parts):
        return None
    ie = p.get("interest_expense")
    return parts[0] - parts[1] - parts[2] - parts[3] - parts[4] - parts[5] - (max(ie, 0) if ie else 0)

def cash_portrait(ocf, icf, cff):
    if any(v is None for v in (ocf, icf, cff)):
        return None
    sig = ("+" if ocf > 0 else "-") + ("+" if icf > 0 else "-") + ("+" if cff > 0 else "-")
    name, note = PORTRAIT[sig]
    return {"signature": sig, "name": name, "note": note}

def consecutive(series, pred):
    """连续 N 期严格判定（时间相邻，禁累计期数替代）"""
    if not series:
        return {"max_consecutive": 0, "triggered": False}
    run = best = 0
    for v in series:
        if v is not None and pred(v):
            run += 1; best = max(best, run)
        else:
            run = 0
    return {"max_consecutive": best, "triggered": best >= 2}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="财报数据 JSON 文件")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    data = json.load(open(args.input, encoding="utf-8"))
    market = data.get("market", "A股")
    sales_cash_base = 1.13 if market == "A股" else 1.0
    periods = data.get("periods", [])
    gaps, rows = [], []

    for p in periods:
        row = {"end_date": p.get("end_date"), "months": p.get("months", 12)}
        if p.get("note"): row["note"] = p["note"]
        rev = p.get("revenue")
        # 盈利类
        row["gross_margin"] = pct(safe_div((rev - p["cogs"]) if rev is not None and p.get("cogs") is not None else None, rev))
        np_ = p.get("np_consolidated") or p.get("np_parent")
        row["net_margin"] = pct(safe_div(np_, rev))
        cp = core_profit(p)
        row["core_profit"] = r2(cp)
        tp = p.get("total_profit")
        if cp is not None and tp:
            row["profit_structure"] = {
                "核心利润(干)": pct(cp / tp),
                "其他收益(补)": pct(safe_div(p.get("other_income") or 0, tp)),
                "投资+公允(投)": pct(safe_div((p.get("investment_income") or 0) + (p.get("fv_change") or 0), tp)),
                "减值(洗)": pct(safe_div((p.get("asset_impairment") or 0) + (p.get("credit_impairment") or 0), tp) and -((p.get("asset_impairment") or 0) + (p.get("credit_impairment") or 0)) / tp),
            }
            oth = p.get("other_income")
            row["core_cash_ratio_R062"] = r2(safe_div(p.get("ocf"), cp + oth if oth is not None else cp))
        # 现金流类
        row["np_cash_ratio"] = r2(safe_div(p.get("ocf"), np_))
        row["sales_cash_ratio"] = {"value": r2(safe_div(p.get("sales_cash"), rev)),
                                   "base": sales_cash_base,
                                   "flag_low": (safe_div(p.get("sales_cash"), rev) or 1) < sales_cash_base - 0.05}
        ocf, capex = p.get("ocf"), p.get("capex")
        row["fcf"] = r2(ocf - capex if ocf is not None and capex is not None else None)
        row["fcf_note"] = "无数据禁0近似" if ocf is None or capex is None else None
        ie = p.get("interest_expense")
        if ie and ie > 0:
            ebit = (np_ or 0) + (p.get("income_tax") or 0) + ie
            row["interest_coverage"] = r2(safe_div(ebit, ie))
        # 资金真实性 R011（年化两级阈值）
        cash, cash_prev, ii = p.get("cash"), p.get("cash_prev"), p.get("interest_income")
        if ii is not None and cash is not None and cash_prev is not None and (cash + cash_prev) > 0:
            months = p.get("months", 12)
            annual_ii = ii * 12 / months
            avg_cash = (cash_prev + cash) / 2
            y = annual_ii / avg_cash
            row["cash_yield_R011"] = {"value_pct": r2(y * 100), "verdict": "PASS" if y >= 0.003 else ("WARN" if y >= 0.0015 else "FAIL")}
        elif ii is None or cash is None:
            gaps.append(f"{p.get('end_date')}: 货币资金/利息收入缺失，R011 无法计算（禁0填充）")
        # 归母/合并偏离 R065
        npc, npp = p.get("np_consolidated"), p.get("np_parent")
        if npc and npp is not None:
            dev = npp / npc
            npm = npc - npp
            v = "PASS" if 0.9 <= dev <= 1.1 else "WARN(核实合并范围)"
            if npm < 0 and abs(npm) > 0.02 * abs(npc):
                v = "FAIL(体外藏亏嫌疑)"
            row["parent_consolidated_deviation_R065"] = {"value_pct": r2(dev * 100), "minority_np": r2(npm), "verdict": v}
        # 透支分红 R066
        div = p.get("dividends_paid")
        if div is not None and npp:
            payout = div / npp
            ncr = safe_div(p.get("ocf"), np_)
            flag = "透支分红" if (p.get("ocf") is not None and p.get("ocf") < 0 and payout > 0.5) else \
                   ("分红不可持续" if payout > 1.0 and (ncr is not None and ncr < 0.3) else "PASS")
            row["dividend_R066"] = {"payout_pct": r2(payout * 100), "verdict": flag}
        # 经营性资金优势 R063
        pay_side = sum(p.get(k) or 0 for k in ("notes_payable", "accounts_payable", "advance_receipts", "contract_liabilities"))
        rec_side = sum(p.get(k) or 0 for k in ("notes_receivable", "accounts_receivable", "prepayments", "contract_assets"))
        if any(p.get(k) is not None for k in ("notes_payable", "accounts_payable", "advance_receipts", "contract_liabilities")):
            adv = pay_side - rec_side
            row["funds_advantage_R063"] = {"value": r2(adv), "over_revenue_pct": pct(safe_div(adv, rev)),
                                           "verdict": "占上下游便宜" if adv > 0 else "被上下游占用"}
        # 存贷双高 R010
        ta, ibd = p.get("total_assets"), p.get("interest_bearing_debt")
        if all(v is not None for v in (ta, cash, ibd, ie, ii)) and ta > 0:
            row["double_high_R010"] = bool(cash >= 0.10 * ta and ibd >= 0.20 * ta and ii > 0 and ie / ii > 3)
        # 增速差（应收/存货 vs 营收，仅正差告警）
        row["portrait"] = cash_portrait(p.get("ocf"), p.get("icf"), p.get("cff"))
        rows.append(row)

    # —— 跨期判定（连续 N 期严格判定） ——
    ccr = [r.get("core_cash_ratio_R062") for r in rows]
    cross = {
        "R062_核心利润获现率": {
            "series": ccr,
            "连续2年lt0.7": consecutive(ccr, lambda v: v < 0.7),
            "连续2年lt0.5或连续3年lt0.6": {
                "lt0.5": consecutive(ccr, lambda v: v < 0.5),
                "lt0.6": consecutive(ccr, lambda v: v < 0.6),
            },
        },
        "肖像漂移": [r["portrait"]["name"] if r.get("portrait") else None for r in rows],
    }
    deducted = [p.get("np_deducted") for p in periods]
    if any(v is not None for v in deducted):
        cross["扣非净利润连续为负"] = consecutive(deducted, lambda v: v is not None and v < 0)
    cy = [r.get("cash_yield_R011", {}).get("value_pct") if isinstance(r.get("cash_yield_R011"), dict) else None for r in rows]
    if any(v is not None for v in cy):
        cross["货币资金收益率连续lt0.15pct"] = consecutive(cy, lambda v: v is not None and v < 0.15)

    out = {
        "skill": "financial-report-risk-scan", "version": "1.1.0",
        "company": data.get("company"), "code": data.get("code"), "market": market,
        "unit": "亿元", "periods_computed": len(rows),
        "calculation_guarantee": "同一输入同一输出；所有缺数据字段标注【无数据】并列入 data_gaps，禁 0 填充",
        "periods": rows, "cross_period": cross, "data_gaps": gaps,
        "note": "本输出为量化计算层；定性规则（R039-R050 业务/治理）、评分与风险等级由分析流程结合本输出判定",
    }
    s = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out:
        open(args.out, "w", encoding="utf-8").write(s)
        print(f"written: {args.out}")
    else:
        print(s)

if __name__ == "__main__":
    main()
