#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
持仓每周跟踪 V1.1.0 — 假设阈值体检脚本（同一输入同一输出，防 LLM 判定幻觉）
用法: python check_thresholds.py <holdings.json> <weekly_data.json> [--out 输出.json]
weekly_data.json 结构: {"observations": [{"assumption_id": "A-01", "observed_value": 1.47, "note": "中报营收同比%"}, ...],
                        "triggered_events": ["H-XX-01"], "leading_events": ["H-XX-02"]}
输出: 逐条假设体检结果（状态判定基于 observations 数值对照 + 事件名单，LLM 只做复核与成文）

输入2 weekly_data.json 结构：
  week 周次 | observations[] [{assumption_id 与holdings.json对应, observed_value 观测值, note 说明,
    status_override 可选:"confirmed"|"invalid" 手动覆盖}] | triggered_events[] 触发假设ID名单 |
  leading_events[] 领先预警ID名单
  注意：阈值数值判定(如"营收同比<+10%是否击穿")由扫描流程比对后写入 observations/triggered，本脚本负责登记与统计"""
import json, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("holdings"); ap.add_argument("weekly"); ap.add_argument("--out", default=None)
    args = ap.parse_args()
    h = json.load(open(args.holdings, encoding="utf-8"))
    w = json.load(open(args.weekly, encoding="utf-8"))
    obs = {o["assumption_id"]: o for o in w.get("observations", [])}
    triggered = set(w.get("triggered_events", []))
    leading = set(w.get("leading_events", []))

    results, counts = [], {"healthy": 0, "leading": 0, "triggered": 0, "invalid": 0, "confirmed": 0, "no_data": 0}
    for hk in h.get("holdings", []):
        for a in hk.get("assumptions", []):
            aid = a.get("id")
            o = obs.get(aid, {})
            if aid in triggered:
                status = "triggered"
            elif aid in leading:
                status = "leading"
            elif o.get("status_override") in ("confirmed", "invalid"):
                status = o["status_override"]
            elif o:
                status = "healthy"  # 有观测无报警=健康（阈值数值判定由观察者提供,脚本只登记）
            else:
                status = "no_data"; counts["no_data"] += 1
                results.append({"id": aid, "holding": hk.get("name"), "status": "no_data",
                                "note": "本周无观测数据——标【待补查】，禁判'无重要事项'"})
                continue
            counts[status] = counts.get(status, 0) + 1
            results.append({"id": aid, "holding": hk.get("name"), "hypothesis": a.get("hypothesis"),
                            "threshold": a.get("threshold") or a.get("falsifier"),
                            "observed": o.get("observed_value"), "note": o.get("note", ""),
                            "status": status, "status_prev": a.get("status")})

    out = {"skill": "portfolio-weekly-tracker", "version": "1.1.0",
           "week": w.get("week"), "portfolio": h.get("portfolio_name"),
           "assumptions_total": len(results), "status_counts": counts,
           "triggered_detail": [r for r in results if r["status"] == "triggered"],
           "leading_detail": [r for r in results if r["status"] == "leading"],
           "no_data_detail": [r for r in results if r["status"] == "no_data"],
           "all_results": results,
           "calculation_guarantee": "同一输入同一输出；no_data 项禁自填禁默判"}
    s = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out: open(args.out, "w", encoding="utf-8").write(s); print(f"written: {args.out}")
    else: print(s)

if __name__ == "__main__":
    main()
